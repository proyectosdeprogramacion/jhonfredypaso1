﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spa_De_Mascotas
{
    internal class Cliente
    {
        //Atributos de la clase
        public string cliente;
        public string mascota;
        public string estrato;
        public string servicio;
        private int costo; 
        private int total;

        //Calcular el costo del servicio
        public void Costo()
        {
            switch (servicio)
            {
                case "Baño y corte, $45.000":
                    costo = 45000;
                    break;
                case "Baño, corte y vacuna antigarrapatas, $80.000":
                    costo = 80000;
                    break;
                case "Baño, corte, Vacunas antigarrapatas y Antiparásitos $100.000":
                    costo = 100000;
                    break;
            }
        }

        //Calcular el descuento del servicio
        public int Calcular_Descuento()
        {
            if (estrato == "1" || estrato == "2")
            {
                total = (costo) - (costo * 15 / 100);
            }
            else if (estrato == "3" || estrato == "4")
            {
                total = (costo) - (costo * 10 / 100);
            }
            else if (estrato == "5" || estrato == "Mayor a 5")
            {
                total = (costo) - (costo * 5 / 100);
            }          

            return total;
        }
    }
}
