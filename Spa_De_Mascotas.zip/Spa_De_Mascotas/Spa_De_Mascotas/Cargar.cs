﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spa_De_Mascotas
{
    public partial class Cargar : Form
    {
        public Cargar()
        {
            InitializeComponent();
        }

        //Regresa al formulario anterior
        private void btn_regresar_Click(object sender, EventArgs e)
        {
            Guardar gd = new Guardar();

            this.Hide();
            gd.ShowDialog();
            this.Close();
        }

        private void txt_cliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_mascota_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_estrato_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_total_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
    }
}
