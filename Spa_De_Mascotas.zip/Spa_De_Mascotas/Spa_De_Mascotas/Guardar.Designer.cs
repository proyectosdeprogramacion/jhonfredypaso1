﻿namespace Spa_De_Mascotas
{
    partial class Guardar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_realizarP = new System.Windows.Forms.Button();
            this.txt_cliente = new System.Windows.Forms.TextBox();
            this.txt_mascota = new System.Windows.Forms.TextBox();
            this.cbb_estrato = new System.Windows.Forms.ComboBox();
            this.cbb_servicio = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_realizarP
            // 
            this.btn_realizarP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_realizarP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(146)))), ((int)(((byte)(44)))));
            this.btn_realizarP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(124)))), ((int)(((byte)(0)))));
            this.btn_realizarP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_realizarP.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_realizarP.ForeColor = System.Drawing.Color.White;
            this.btn_realizarP.Location = new System.Drawing.Point(169, 379);
            this.btn_realizarP.Name = "btn_realizarP";
            this.btn_realizarP.Size = new System.Drawing.Size(170, 50);
            this.btn_realizarP.TabIndex = 3;
            this.btn_realizarP.Text = "Realizar pedido";
            this.btn_realizarP.UseVisualStyleBackColor = false;
            this.btn_realizarP.Click += new System.EventHandler(this.btn_realizarP_Click);
            // 
            // txt_cliente
            // 
            this.txt_cliente.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_cliente.BackColor = System.Drawing.Color.White;
            this.txt_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cliente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_cliente.Location = new System.Drawing.Point(162, 94);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(200, 29);
            this.txt_cliente.TabIndex = 4;
            // 
            // txt_mascota
            // 
            this.txt_mascota.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_mascota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_mascota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_mascota.Location = new System.Drawing.Point(162, 148);
            this.txt_mascota.Name = "txt_mascota";
            this.txt_mascota.Size = new System.Drawing.Size(200, 29);
            this.txt_mascota.TabIndex = 5;
            // 
            // cbb_estrato
            // 
            this.cbb_estrato.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbb_estrato.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbb_estrato.FormattingEnabled = true;
            this.cbb_estrato.Items.AddRange(new object[] {
            "Estrato 1 o 2",
            "Estrato 3 o 4",
            "Estrato mayor o igual a 5"});
            this.cbb_estrato.Location = new System.Drawing.Point(162, 196);
            this.cbb_estrato.Name = "cbb_estrato";
            this.cbb_estrato.Size = new System.Drawing.Size(200, 29);
            this.cbb_estrato.TabIndex = 6;
            this.cbb_estrato.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbb_estrato_KeyPress);
            // 
            // cbb_servicio
            // 
            this.cbb_servicio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbb_servicio.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbb_servicio.FormattingEnabled = true;
            this.cbb_servicio.Items.AddRange(new object[] {
            "Baño y corte, $45.000",
            "Baño, corte y vacuna antigarrapatas, $80.000",
            "Baño, corte, Vacunas antigarrapatas y Antiparásitos $100.000"});
            this.cbb_servicio.Location = new System.Drawing.Point(162, 242);
            this.cbb_servicio.Name = "cbb_servicio";
            this.cbb_servicio.Size = new System.Drawing.Size(300, 29);
            this.cbb_servicio.TabIndex = 7;
            this.cbb_servicio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbb_servicio_KeyPress);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(56, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Cliente";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(56, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 21);
            this.label2.TabIndex = 9;
            this.label2.Text = "Mascota";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(56, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "Estrato";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(56, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 21);
            this.label4.TabIndex = 11;
            this.label4.Text = "Servicio";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(138, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(231, 37);
            this.label5.TabIndex = 12;
            this.label5.Text = "Spa de Mascotas";
            // 
            // Guardar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(513, 484);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbb_servicio);
            this.Controls.Add(this.cbb_estrato);
            this.Controls.Add(this.txt_mascota);
            this.Controls.Add(this.txt_cliente);
            this.Controls.Add(this.btn_realizarP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Guardar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guardar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_realizarP;
        private TextBox txt_cliente;
        private TextBox txt_mascota;
        private ComboBox cbb_estrato;
        private ComboBox cbb_servicio;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}