﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spa_De_Mascotas
{
    public partial class Guardar : Form
    {
        public Guardar()
        {
            InitializeComponent();
        }

        private void cbb_estrato_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbb_servicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        Cliente cln = new Cliente();

        //Carga los datos en el siguiente formulario
        private void SiguienteFormulario()
        {
            try
            {
                Cargar cr = new Cargar();


                cr.txt_cliente.Text = cln.cliente;
                cr.txt_mascota.Text = cln.mascota;
                cr.txt_estrato.Text = cln.estrato;
                cln.Costo();
                cr.txt_total.Text = cln.Calcular_Descuento().ToString(); ;

                this.Hide();
                cr.ShowDialog();
                this.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }          
        }

        //Envia los datos para calcular el total a pagar
        private void btn_realizarP_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_cliente.Text == "" || txt_mascota.Text == "" || cbb_estrato.Text == "" || cbb_servicio.Text == "")
                {
                    MessageBox.Show("Complete todos los datos para continuar");
                }
                else
                {
                    cln.cliente = txt_cliente.Text;
                    cln.mascota = txt_mascota.Text;
                    cln.estrato = cbb_estrato.Text;
                    cln.servicio = cbb_servicio.Text;

                    SiguienteFormulario();
                }                
            }
            catch (Exception ec)
            {

                MessageBox.Show(ec.Message);
            }            
        }
    }
}
