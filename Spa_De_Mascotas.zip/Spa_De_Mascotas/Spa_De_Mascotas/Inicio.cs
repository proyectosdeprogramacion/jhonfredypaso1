﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spa_De_Mascotas
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        //Pide la contraseña para iniciar
        private void btn_IniciarS_Click(object sender, EventArgs e)
        {
            if (txt_Contraseña.Text == "123")
            {
                Guardar frm = new Guardar();

                this.Hide();
                frm.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Contraseña errada");
            }
        }
    }
}
